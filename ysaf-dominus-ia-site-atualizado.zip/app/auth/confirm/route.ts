import { NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@supabase/ssr"

export async function GET(request: NextRequest) {
  const url = new URL(request.url)

  const token_hash = url.searchParams.get("token_hash")
  const type = url.searchParams.get("type") as "email" | null
  const next = url.searchParams.get("next") ?? "/dashboard"

  if (!token_hash || !type) {
    return NextResponse.redirect(new URL(`/login?error=missing_params`, url.origin))
  }

  // cria a resposta (redirect) ANTES, pra poder setar cookies nela
  const response = NextResponse.redirect(new URL(next, url.origin))

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get: (name) => request.cookies.get(name)?.value,
        set: (name, value, options) => {
          response.cookies.set({ name, value, ...options })
        },
        remove: (name, options) => {
          response.cookies.set({ name, value: "", ...options })
        },
      },
    }
  )

  const { error } = await supabase.auth.verifyOtp({ type, token_hash })

  if (error) {
    return NextResponse.redirect(new URL(`/login?error=email_confirm_failed`, url.origin))
  }

  return response
}
