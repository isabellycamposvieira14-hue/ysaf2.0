"use client"

import React from "react"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import {
  HeadphonesIcon,
  MessageSquare,
  Mail,
  Clock,
  Send,
  ChevronDown,
  ChevronUp,
} from "lucide-react"

const faqs = [
  {
    question: "Como acesso os modulos do curso?",
    answer:
      "Apos o login, va ao Dashboard e clique em 'Modulos do Curso'. Todos os modulos desbloqueados estarao disponiveis para acesso imediato. Os modulos sao liberados conforme seu progresso.",
  },
  {
    question: "Posso baixar os materiais para estudar offline?",
    answer:
      "Sim! Todos os materiais em PDF, planilhas e templates podem ser baixados na secao 'Materiais e Bonus'. Basta clicar no botao de download ao lado de cada material.",
  },
  {
    question: "Como faco para entrar no grupo exclusivo?",
    answer:
      "Acesse a secao 'Grupo Exclusivo' no menu lateral e clique no botao 'Entrar no Grupo'. Voce sera redirecionado para o grupo do WhatsApp da comunidade YSAF Dominus IA.",
  },
  {
    question: "As ferramentas de IA mencionadas no curso sao gratuitas?",
    answer:
      "Muitas das ferramentas possuem planos gratuitos ou periodos de teste. O curso ensina a utilizar tanto opcoes gratuitas quanto pagas, priorizando sempre o melhor custo-beneficio para cada etapa.",
  },
  {
    question: "Quanto tempo tenho acesso ao curso?",
    answer:
      "Seu acesso e vitalicio. Uma vez membro, voce pode acessar todo o conteudo, atualizacoes futuras e novos materiais sem custo adicional.",
  },
  {
    question: "Como funciona o plano de 30 dias?",
    answer:
      "O plano de 30 dias e detalhado no Modulo 14. Semana 1: Definicao de nicho e ferramentas. Semana 2: Criacao do produto com IA. Semana 3: Configuracao de automacoes. Semana 4: Lancamento e primeiras vendas.",
  },
]

export default function SuportePage() {
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null)
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [message, setMessage] = useState("")
  const [sent, setSent] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    await new Promise((resolve) => setTimeout(resolve, 800))
    setSent(true)
    setName("")
    setEmail("")
    setMessage("")
    setTimeout(() => setSent(false), 3000)
  }

  return (
    <div className="min-h-screen">
      <DashboardHeader />

      <div className="p-6">
        <div className="mb-8">
          <h1 className="text-balance text-2xl font-bold text-foreground">
            {"Suporte"}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {"Precisa de ajuda? Estamos aqui para voce."}
          </p>
        </div>

        {/* Contact cards */}
        <div className="mb-8 grid gap-4 sm:grid-cols-3">
          <div className="rounded-xl border border-border bg-card p-5">
            <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg border border-primary/20 bg-primary/10">
              <MessageSquare className="h-5 w-5 text-primary" />
            </div>
            <h3 className="text-sm font-semibold text-foreground">{"WhatsApp"}</h3>
            <p className="mt-1 text-xs text-muted-foreground">{"Resposta em ate 2 horas"}</p>
          </div>
          <div className="rounded-xl border border-border bg-card p-5">
            <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg border border-primary/20 bg-primary/10">
              <Mail className="h-5 w-5 text-primary" />
            </div>
            <h3 className="text-sm font-semibold text-foreground">{"E-mail"}</h3>
            <p className="mt-1 text-xs text-muted-foreground">{"suporte@ysafmidia.com"}</p>
          </div>
          <div className="rounded-xl border border-border bg-card p-5">
            <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg border border-primary/20 bg-primary/10">
              <Clock className="h-5 w-5 text-primary" />
            </div>
            <h3 className="text-sm font-semibold text-foreground">{"Horario"}</h3>
            <p className="mt-1 text-xs text-muted-foreground">{"Seg-Sex, 9h as 18h"}</p>
          </div>
        </div>

        <div className="grid gap-8 lg:grid-cols-2">
          {/* FAQ */}
          <div>
            <h2 className="mb-4 text-lg font-semibold text-foreground">
              {"Perguntas Frequentes"}
            </h2>
            <div className="space-y-2">
              {faqs.map((faq, index) => (
                <div
                  key={`faq-${index}`}
                  className="overflow-hidden rounded-xl border border-border bg-card"
                >
                  <button
                    onClick={() =>
                      setExpandedFaq(expandedFaq === index ? null : index)
                    }
                    className="flex w-full items-center justify-between px-5 py-4 text-left"
                  >
                    <p className="pr-4 text-sm font-medium text-foreground">
                      {faq.question}
                    </p>
                    {expandedFaq === index ? (
                      <ChevronUp className="h-4 w-4 shrink-0 text-muted-foreground" />
                    ) : (
                      <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" />
                    )}
                  </button>
                  {expandedFaq === index && (
                    <div className="border-t border-border px-5 py-4">
                      <p className="text-sm leading-relaxed text-muted-foreground">
                        {faq.answer}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Contact form */}
          <div>
            <h2 className="mb-4 text-lg font-semibold text-foreground">
              {"Enviar Mensagem"}
            </h2>
            <form
              onSubmit={handleSubmit}
              className="rounded-xl border border-border bg-card p-5"
            >
              <div className="space-y-4">
                <div>
                  <label htmlFor="name" className="mb-1 block text-xs font-medium text-muted-foreground">
                    {"Nome"}
                  </label>
                  <input
                    id="name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    className="h-10 w-full rounded-lg border border-border bg-background px-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                    placeholder="Seu nome"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="mb-1 block text-xs font-medium text-muted-foreground">
                    {"E-mail"}
                  </label>
                  <input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="h-10 w-full rounded-lg border border-border bg-background px-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                    placeholder="seu@email.com"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="mb-1 block text-xs font-medium text-muted-foreground">
                    {"Mensagem"}
                  </label>
                  <textarea
                    id="message"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    required
                    rows={4}
                    className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                    placeholder="Descreva sua duvida ou problema..."
                  />
                </div>
                <button
                  type="submit"
                  className="inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110"
                >
                  <Send className="h-4 w-4" />
                  {sent ? "Enviado!" : "Enviar Mensagem"}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
