"use client"

import React from "react"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import {
  User,
  Mail,
  Calendar,
  Shield,
  BookOpen,
  Award,
  Save,
} from "lucide-react"

export default function PerfilPage() {
  const [name, setName] = useState("Membro YSAF Dominus IA")
  const [email, setEmail] = useState("membro@email.com")
  const [saved, setSaved] = useState(false)

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    await new Promise((resolve) => setTimeout(resolve, 600))
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <div className="min-h-screen">
      <DashboardHeader />

      <div className="p-6">
        <div className="mb-8">
          <h1 className="text-balance text-2xl font-bold text-foreground">
            {"Meu Perfil"}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {"Gerencie suas informacoes e acompanhe seu progresso."}
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Profile card */}
          <div className="lg:col-span-1">
            <div className="rounded-xl border border-border bg-card p-6">
              <div className="flex flex-col items-center">
                <div className="flex h-20 w-20 items-center justify-center rounded-full border-2 border-primary/30 bg-primary/10">
                  <User className="h-10 w-10 text-primary" />
                </div>
                <h2 className="mt-4 text-lg font-semibold text-foreground">{name}</h2>
                <p className="text-sm text-muted-foreground">{"Membro YSAF Dominus IA"}</p>

                <div className="mt-6 w-full space-y-3">
                  <div className="flex items-center gap-3 text-sm">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span className="text-muted-foreground">{email}</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="text-muted-foreground">{"Membro desde Jan 2026"}</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <Shield className="h-4 w-4 text-muted-foreground" />
                    <span className="text-muted-foreground">{"Acesso vitalicio"}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Stats */}
            <div className="mt-4 space-y-3">
              <div className="flex items-center gap-4 rounded-xl border border-border bg-card p-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <BookOpen className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">{"Aulas concluidas"}</p>
                  <p className="text-lg font-bold text-foreground">
                    {"7"} <span className="text-sm font-normal text-muted-foreground">/ 65</span>
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-4 rounded-xl border border-border bg-card p-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-500/10">
                  <Award className="h-5 w-5 text-emerald-400" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">{"Modulos completos"}</p>
                  <p className="text-lg font-bold text-foreground">
                    {"3"} <span className="text-sm font-normal text-muted-foreground">/ 14</span>
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Edit form */}
          <div className="lg:col-span-2">
            <div className="rounded-xl border border-border bg-card p-6">
              <h2 className="mb-5 text-lg font-semibold text-foreground">
                {"Editar Informacoes"}
              </h2>
              <form onSubmit={handleSave} className="space-y-5">
                <div>
                  <label htmlFor="profile-name" className="mb-1 block text-xs font-medium text-muted-foreground">
                    {"Nome completo"}
                  </label>
                  <input
                    id="profile-name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="h-11 w-full rounded-lg border border-border bg-background px-4 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                  />
                </div>
                <div>
                  <label htmlFor="profile-email" className="mb-1 block text-xs font-medium text-muted-foreground">
                    {"E-mail"}
                  </label>
                  <input
                    id="profile-email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="h-11 w-full rounded-lg border border-border bg-background px-4 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                  />
                </div>
                <div>
                  <label htmlFor="profile-password" className="mb-1 block text-xs font-medium text-muted-foreground">
                    {"Nova senha (opcional)"}
                  </label>
                  <input
                    id="profile-password"
                    type="password"
                    placeholder="Deixe em branco para manter a atual"
                    className="h-11 w-full rounded-lg border border-border bg-background px-4 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                  />
                </div>
                <button
                  type="submit"
                  className="inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110"
                >
                  <Save className="h-4 w-4" />
                  {saved ? "Salvo!" : "Salvar Alteracoes"}
                </button>
              </form>
            </div>

            {/* Course progress */}
            <div className="mt-6 rounded-xl border border-border bg-card p-6">
              <h2 className="mb-5 text-lg font-semibold text-foreground">
                {"Progresso no Curso"}
              </h2>
              <div className="space-y-4">
                {[
                  { name: "Modulo 1: A Realidade do Mercado Digital", progress: 100 },
                  { name: "Modulo 2: IA: A Maior Alavanca Financeira", progress: 100 },
                  { name: "Modulo 3: Tipos de IA e Como Monetizar", progress: 100 },
                  { name: "Modulo 4: IA Como Fabrica de Produtos Digitais", progress: 40 },
                  { name: "Modulo 5: A Psicologia da Venda", progress: 0 },
                ].map((mod) => (
                  <div key={mod.name}>
                    <div className="mb-1 flex items-center justify-between">
                      <p className="text-xs font-medium text-muted-foreground">
                        {mod.name}
                      </p>
                      <p className="text-xs font-bold text-primary">{mod.progress}%</p>
                    </div>
                    <div className="h-1.5 overflow-hidden rounded-full bg-secondary">
                      <div
                        className="h-full rounded-full bg-primary transition-all"
                        style={{ width: `${mod.progress}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
