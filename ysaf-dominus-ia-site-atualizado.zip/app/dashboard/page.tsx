"use client"

import Link from "next/link"
import {
  BookOpen,
  Users,
  FileDown,
  ArrowRight,
  Brain,
  Cpu,
  MessageSquare,
  TrendingUp,
} from "lucide-react"
import { DashboardHeader } from "@/components/dashboard-header"

const mainCards = [
  {
    title: "Modulos do Curso",
    description: "14 modulos completos sobre IA, vendas, automacao e escala digital.",
    icon: BookOpen,
    href: "/dashboard/modulos",
    cta: "Acessar Modulos",
  },
  {
    title: "Grupo Exclusivo",
    description: "Networking, suporte e atualizacoes estrategicas com a comunidade.",
    icon: Users,
    href: "/dashboard/grupo",
    cta: "Entrar no Grupo",
  },
  {
    title: "Materiais e Bonus",
    description: "Templates, planilhas, prompts de IA e ferramentas praticas.",
    icon: FileDown,
    href: "/dashboard/materiais",
    cta: "Baixar Materiais",
  },
]

const highlights = [
  {
    icon: Brain,
    title: "IA como Alavanca",
    description: "Multiplique tempo, dinheiro e escala com inteligencia artificial.",
  },
  {
    icon: Cpu,
    title: "Automacao Total",
    description: "WhatsApp e Instagram no piloto automatico 24/7.",
  },
  {
    icon: MessageSquare,
    title: "Scripts Profissionais",
    description: "Copies e scripts prontos para vender com alta conversao.",
  },
  {
    icon: TrendingUp,
    title: "Plano de 30 Dias",
    description: "Roteiro passo a passo para suas primeiras vendas.",
  },
]

export default function DashboardPage() {
  return (
    <div className="min-h-screen">
      <DashboardHeader />

      <div className="p-6">
        {/* Welcome section */}
        <div className="mb-8">
          <h1 className="text-balance text-2xl font-bold text-foreground">
            {"Sua area estrategica"}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {"IA Lucrativa: Como Faturar Alto na Internet Usando Inteligencia Artificial, Automacao e Marketing Digital."}
          </p>
        </div>

        {/* Main cards */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {mainCards.map((card) => (
            <Link
              key={card.href}
              href={card.href}
              className="group relative overflow-hidden rounded-xl border border-border bg-card p-6 transition-all duration-300 hover:border-primary/40 hover:shadow-[0_0_30px_-5px_hsla(260,100%,59%,0.15)]"
            >
              <div className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-primary/5 opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-100" />

              <div className="relative">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg border border-primary/20 bg-primary/10">
                  <card.icon className="h-6 w-6 text-primary" />
                </div>

                <h2 className="mb-2 text-lg font-semibold text-foreground">
                  {card.title}
                </h2>
                <p className="mb-6 text-sm leading-relaxed text-muted-foreground">
                  {card.description}
                </p>

                <span className="inline-flex items-center gap-2 text-sm font-semibold text-primary transition-all group-hover:gap-3">
                  {card.cta}
                  <ArrowRight className="h-4 w-4" />
                </span>
              </div>
            </Link>
          ))}
        </div>

        {/* Quick stats */}
        <div className="mt-8 grid gap-4 sm:grid-cols-4">
          <div className="rounded-lg border border-border bg-card p-4">
            <p className="text-xs font-medium text-muted-foreground">{"Modulos disponiveis"}</p>
            <p className="mt-1 text-2xl font-bold text-foreground">14</p>
          </div>
          <div className="rounded-lg border border-border bg-card p-4">
            <p className="text-xs font-medium text-muted-foreground">{"Aulas concluidas"}</p>
            <p className="mt-1 text-2xl font-bold text-foreground">
              {"7"} <span className="text-sm font-normal text-muted-foreground">/ 65</span>
            </p>
          </div>
          <div className="rounded-lg border border-border bg-card p-4">
            <p className="text-xs font-medium text-muted-foreground">{"Materiais baixados"}</p>
            <p className="mt-1 text-2xl font-bold text-foreground">3</p>
          </div>
          <div className="rounded-lg border border-border bg-card p-4">
            <p className="text-xs font-medium text-muted-foreground">{"Dias como membro"}</p>
            <p className="mt-1 text-2xl font-bold text-foreground">14</p>
          </div>
        </div>

        {/* Course highlights */}
        <div className="mt-8">
          <h2 className="mb-4 text-lg font-semibold text-foreground">
            {"O que voce vai dominar"}
          </h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {highlights.map((item) => (
              <div
                key={item.title}
                className="rounded-xl border border-border bg-card p-5"
              >
                <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg border border-primary/20 bg-primary/10">
                  <item.icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="text-sm font-semibold text-foreground">{item.title}</h3>
                <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
