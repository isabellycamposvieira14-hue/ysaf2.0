"use client"

import {
  FileDown,
  FileText,
  Layout,
  Wand2,
  BookOpen,
  Megaphone,
  Download,
} from "lucide-react"

const materials = [
  {
    category: "Ebook e Guias",
    icon: BookOpen,
    items: [
      {
        title: "YSAF Dominus IA — eBook Completo (PDF)",
        description: "O eBook completo em PDF.",
        size: "PDF",
        href: "/downloads/YSAF-Dominus-IA-ebook.pdf",
      },
      {
        title: "Guia de Ferramentas de IA (PDF)",
        description: "Lista organizada de ferramentas + recomendações de uso.",
        size: "PDF",
        href: "/downloads/Guia-de-Ferramentas-de-IA.pdf",
      },
      {
        title: "Glossário de Marketing Digital (PDF)",
        description: "Termos essenciais de marketing, IA e automação explicados de forma simples.",
        size: "PDF",
        href: "/downloads/Glossario-Marketing-Digital.pdf",
      },
    ],
  },
  {
    category: "Templates e Scripts",
    icon: FileText,
    items: [
      {
        title: "Scripts de Conversa para WhatsApp (TXT)",
        description: "Abertura, diagnóstico, objeções e fechamento.",
        size: "TXT",
        href: "/downloads/Scripts-WhatsApp.txt",
      },
      {
        title: "Templates de Copy para Anúncios (PDF)",
        description: "Frameworks AIDA e PAS prontos para adaptar.",
        size: "PDF",
        href: "/downloads/Templates-Copy-Anuncios.pdf",
      },
      {
        title: "Scripts de Automação (TXT)",
        description: "Fluxos base para ManyChat e sequências de follow-up.",
        size: "TXT",
        href: "/downloads/Scripts-Automacao-ManyChat.txt",
      },
    ],
  },
  {
    category: "Planilhas e Checklists",
    icon: Layout,
    items: [
      {
        title: "Planilha de Métricas (Meta Ads) (XLSX)",
        description: "Acompanhe CPM, CTR, CPC, CPA e ROAS das campanhas.",
        size: "XLSX",
        href: "/downloads/Planilha-Metricas-Meta-Ads.xlsx",
      },
      {
        title: "Checklist do Plano de 30 Dias (PDF)",
        description: "Passo a passo das 4 semanas de implementação.",
        size: "PDF",
        href: "/downloads/Checklist-Plano-30-Dias.pdf",
      },
      {
        title: "Mapa de Funil (PNG)",
        description: "Diagrama visual do funil: anúncio → captura → WhatsApp → venda → entrega.",
        size: "PNG",
        href: "/downloads/Mapa-de-Funil.png",
      },
    ],
  },
  {
    category: "Prompts de IA",
    icon: Wand2,
    items: [
      {
        title: "Biblioteca de Prompts para ChatGPT (TXT)",
        description: "Prompts para copywriting, roteiros, ebooks e estratégia.",
        size: "TXT",
        href: "/downloads/Prompts-ChatGPT.txt",
      },
      {
        title: "Prompts para Imagens (TXT)",
        description: "Templates para criar criativos e capas com estilo consistente.",
        size: "TXT",
        href: "/downloads/Prompts-Imagens.txt",
      },
      {
        title: "Prompts para Análise de Dados (TXT)",
        description: "Prompts para interpretar métricas e criar hipóteses de testes.",
        size: "TXT",
        href: "/downloads/Prompts-Analise-Dados.txt",
      },
    ],
  },
  {
    category: "Bônus Exclusivos",
    icon: Megaphone,
    items: [
      {
        title: "Bônus: Mini Curso — Tráfego Orgânico com IA (MP4)",
        description: "Vídeo bônus para download.",
        size: "MP4",
        href: "/downloads/Bonus-MiniCurso-Trafego-Organico.mp4",
      },
      {
        title: "Bônus: Masterclass — Funis de WhatsApp (MP4)",
        description: "Gravação bônus para download.",
        size: "MP4",
        href: "/downloads/Bonus-Masterclass-Funis-WhatsApp.mp4",
      },
    ],
  },
]


export default function MateriaisPage() {
  return (
    <div className="min-h-screen">
      <DashboardHeader />

      <div className="p-6">
        <div className="mb-8">
          <h1 className="text-balance text-2xl font-bold text-foreground">
            {"Materiais e Bônus"}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {"Arquivos oficiais do YSAF Dominus IA: downloads de materiais, prompts, planilhas e bônus."}
          </p>
        </div>

        {/* Stats */}
        <div className="mb-8 grid gap-4 sm:grid-cols-3">
          <div className="rounded-xl border border-border bg-card p-4">
            <p className="text-xs font-medium text-muted-foreground">{"Total de materiais"}</p>
            <p className="mt-1 text-2xl font-bold text-foreground">14</p>
          </div>
          <div className="rounded-xl border border-border bg-card p-4">
            <p className="text-xs font-medium text-muted-foreground">{"Categorias"}</p>
            <p className="mt-1 text-2xl font-bold text-foreground">5</p>
          </div>
          <div className="rounded-xl border border-border bg-card p-4">
            <p className="text-xs font-medium text-muted-foreground">{"Bonus exclusivos"}</p>
            <p className="mt-1 text-2xl font-bold text-foreground">2</p>
          </div>
        </div>

        {/* Materials by category */}
        <div className="space-y-8">
          {materials.map((category) => (
            <div key={category.category}>
              <div className="mb-4 flex items-center gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg border border-primary/20 bg-primary/10">
                  <category.icon className="h-4 w-4 text-primary" />
                </div>
                <h2 className="text-lg font-semibold text-foreground">
                  {category.category}
                </h2>
              </div>

              <div className="grid gap-3">
                {category.items.map((item) => (
                  <div
                    key={item.title}
                    className="group flex items-center gap-4 rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/30"
                  >
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-secondary">
                      <FileDown className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-foreground">
                        {item.title}
                      </p>
                      <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">
                        {item.description}
                      </p>
                    </div>
                    <div className="flex shrink-0 items-center gap-3">
                      <span className="text-xs text-muted-foreground">{item.size}</span>
                      <a
                        href={item.href}
                        download
                        className="flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-secondary text-muted-foreground transition-all hover:border-primary/30 hover:text-primary"
                        aria-label={`Baixar: ${item.title}`}
                      >
                        <Download className="h-4 w-4" />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
