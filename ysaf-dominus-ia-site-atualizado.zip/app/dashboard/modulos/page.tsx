"use client"

import Link from "next/link"
import Image from "next/image"
import { DashboardHeader } from "@/components/dashboard-header"
import { chapters } from "@/lib/course-data"
import {
  BookOpen,
  ArrowRight,
  Clock,
} from "lucide-react"

export default function ModulosPage() {
  return (
    <div className="min-h-screen">
      <DashboardHeader />

      <div className="p-4 sm:p-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-balance text-2xl font-bold text-foreground">
            {"Modulos do Curso"}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {"IA Lucrativa: Como Faturar Alto na Internet Usando Inteligencia Artificial"}
          </p>
          <p className="mt-3 text-xs text-muted-foreground">
            {chapters.length + " capitulos disponíveis"}
          </p>
        </div>

        {/* Chapters grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {chapters.map((chapter) => (
            <Link
              key={chapter.id}
              href={`/dashboard/modulos/${chapter.id}`}
              className="group relative flex flex-col overflow-hidden rounded-xl border border-border bg-card transition-all duration-300 hover:border-primary/40 hover:shadow-[0_0_30px_-5px_hsla(260,100%,59%,0.15)]"
            >
              {/* Image */}
              <div className="relative aspect-[16/9] w-full overflow-hidden">
                <Image
                  src={chapter.image || "/placeholder.svg"}
                  alt={chapter.title}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
                <div className="absolute bottom-3 left-3">
                  <span className="inline-flex items-center justify-center rounded-lg bg-primary/90 px-2.5 py-1 text-xs font-bold text-primary-foreground">
                    {chapter.number}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="flex flex-1 flex-col p-4">
                <h2 className="text-base font-semibold text-foreground group-hover:text-primary transition-colors">
                  {chapter.title}
                </h2>
                <p className="mt-1.5 flex-1 text-sm leading-relaxed text-muted-foreground line-clamp-2">
                  {chapter.description}
                </p>

                <div className="mt-4 flex items-center justify-between">
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {chapter.readTime}
                    </span>
                    <span className="flex items-center gap-1">
                      <BookOpen className="h-3 w-3" />
                      {"Ebook"}
                    </span>
                  </div>
                  <ArrowRight className="h-4 w-4 text-muted-foreground transition-all group-hover:translate-x-1 group-hover:text-primary" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
