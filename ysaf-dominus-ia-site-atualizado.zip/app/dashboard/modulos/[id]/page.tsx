"use client"

import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { useState, useEffect, useRef } from "react"
import {
  ArrowLeft,
  CheckCircle2,
  BookOpen,
  ChevronUp,
  Share2,
  BookmarkPlus,
} from "lucide-react"
import { DashboardHeader } from "@/components/dashboard-header"
import { getChapterById, chapters } from "@/lib/course-data"
import type { ContentBlock } from "@/lib/course-data"

function ContentRenderer({ block, index }: { block: ContentBlock; index: number }) {
  switch (block.type) {
    case "heading":
      return (
        <h2
          className="mt-10 mb-6 text-xl font-bold leading-tight text-foreground sm:text-2xl"
        >
          {block.content}
        </h2>
      )
    case "subheading":
      return (
        <h3
          className="mt-8 mb-4 text-lg font-semibold text-foreground"
        >
          {block.content}
        </h3>
      )
    case "text":
      return (
        <p className="mb-5 text-[15px] leading-[1.85] text-muted-foreground sm:text-base">
          {block.content}
        </p>
      )
    case "quote":
      return (
        <blockquote className="my-8 border-l-4 border-primary/60 bg-primary/5 py-5 pl-6 pr-5 rounded-r-lg">
          <p className="text-[15px] italic leading-[1.8] text-foreground/90 sm:text-base">
            {block.content}
          </p>
        </blockquote>
      )
    case "highlight":
      return (
        <div className="my-8 rounded-xl border border-primary/20 bg-primary/5 p-5 sm:p-6">
          <p className="text-[15px] font-medium leading-[1.8] text-foreground/90 sm:text-base">
            {block.content}
          </p>
        </div>
      )
    case "list":
      return (
        <ul className="my-5 space-y-3 pl-1">
          {block.items?.map((item, i) => (
            <li key={`list-${index}-${i}`} className="flex gap-3">
              <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
              <span className="text-[15px] leading-[1.8] text-muted-foreground sm:text-base">
                {item}
              </span>
            </li>
          ))}
        </ul>
      )
    case "image":
      return (
        <figure className="my-8 overflow-hidden rounded-xl">
          <div className="relative aspect-[16/9] w-full">
            <Image
              src={block.src || ""}
              alt={block.alt || ""}
              fill
              className="object-cover"
              sizes="(max-width: 768px) 100vw, 720px"
            />
          </div>
          {block.caption && (
            <figcaption className="mt-3 text-center text-xs italic text-muted-foreground">
              {block.caption}
            </figcaption>
          )}
        </figure>
      )
    case "divider":
      return (
        <div className="my-8 flex items-center justify-center gap-3">
          <span className="h-px flex-1 bg-border" />
          <span className="h-1.5 w-1.5 rounded-full bg-primary/40" />
          <span className="h-px flex-1 bg-border" />
        </div>
      )
    case "table":
      if (!block.rows || block.rows.length === 0) return null
      const headers = block.rows[0]
      const dataRows = block.rows.slice(1)
      return (
        <div className="my-8 overflow-x-auto rounded-xl border border-border">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-card">
                {headers.map((h, i) => (
                  <th
                    key={`th-${index}-${i}`}
                    className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-foreground"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {dataRows.map((row, ri) => (
                <tr key={`tr-${index}-${ri}`} className="border-b border-border/50 last:border-0">
                  {row.map((cell, ci) => (
                    <td
                      key={`td-${index}-${ri}-${ci}`}
                      className={`px-4 py-3 text-[13px] leading-relaxed ${ci === 0 ? "font-medium text-foreground" : "text-muted-foreground"}`}
                    >
                      {cell}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )
    default:
      return null
  }
}

export default function ChapterReaderPage() {
  const params = useParams()
  const router = useRouter()
  const chapterId = Number(params.id)
  const chapter = getChapterById(chapterId)

  const [scrollProgress, setScrollProgress] = useState(0)
  const [showBackToTop, setShowBackToTop] = useState(false)
  const [isCompleted, setIsCompleted] = useState(false)
  const contentRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleScroll = () => {
      const winScroll = document.documentElement.scrollTop
      const height = document.documentElement.scrollHeight - document.documentElement.clientHeight
      const scrolled = height > 0 ? (winScroll / height) * 100 : 0
      setScrollProgress(scrolled)
      setShowBackToTop(winScroll > 600)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  if (!chapter) {
    return (
      <div className="min-h-screen">
        <DashboardHeader />
        <div className="flex flex-col items-center justify-center p-12">
          <p className="text-lg font-semibold text-foreground">
            {"Capitulo nao encontrado"}
          </p>
          <Link
            href="/dashboard/modulos"
            className="mt-4 text-sm text-primary hover:underline"
          >
            {"Voltar aos modulos"}
          </Link>
        </div>
      </div>
    )
  }

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  return (
    <div className="min-h-screen">
      <DashboardHeader />

      {/* Reading progress bar */}
      <div className="fixed left-0 top-0 z-50 h-1 w-full bg-transparent">
        <div
          className="h-full bg-primary transition-all duration-150 ease-out"
          style={{ width: `${scrollProgress}%` }}
        />
      </div>

      <div className="p-4 sm:p-6">
        {/* Back link */}
        <button
          onClick={() => router.push("/dashboard/modulos")}
          className="mb-6 inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
          type="button"
        >
          <ArrowLeft className="h-4 w-4" />
          {"Voltar aos modulos"}
        </button>

        {/* Chapter header card */}
        <div className="mx-auto mb-10 max-w-3xl">
          <div className="mb-6 flex items-center gap-3">
            <span className="inline-flex items-center justify-center rounded-lg bg-primary/10 px-3 py-1.5 text-xs font-bold text-primary">
              {"Capitulo " + chapter.number}
            </span>
            <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <BookOpen className="h-3.5 w-3.5" />
              {chapter.readTime}
            </span>
          </div>

          <h1 className="text-balance text-2xl font-bold leading-tight text-foreground sm:text-3xl lg:text-4xl">
            {chapter.title}
          </h1>
          <p className="mt-3 text-pretty text-base leading-relaxed text-muted-foreground sm:text-lg">
            {chapter.description}
          </p>

          {/* Actions bar */}
          <div className="mt-6 flex flex-wrap items-center gap-3">
            <button
              onClick={() => setIsCompleted(!isCompleted)}
              className={`inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium transition-all ${
                isCompleted
                  ? "bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20"
                  : "bg-secondary text-foreground hover:bg-secondary/80"
              }`}
              type="button"
            >
              {isCompleted ? (
                <>
                  <CheckCircle2 className="h-4 w-4" />
                  {"Capitulo concluido"}
                </>
              ) : (
                <>
                  <CheckCircle2 className="h-4 w-4" />
                  {"Marcar como concluido"}
                </>
              )}
            </button>
            <button
              className="inline-flex items-center gap-2 rounded-lg bg-secondary px-4 py-2.5 text-sm font-medium text-foreground transition-all hover:bg-secondary/80"
              type="button"
            >
              <BookmarkPlus className="h-4 w-4" />
              {"Salvar"}
            </button>
            <button
              className="inline-flex items-center gap-2 rounded-lg bg-secondary px-4 py-2.5 text-sm font-medium text-foreground transition-all hover:bg-secondary/80"
              type="button"
            >
              <Share2 className="h-4 w-4" />
              {"Compartilhar"}
            </button>
          </div>
        </div>

        {/* Ebook content */}
        <article ref={contentRef} className="mx-auto max-w-3xl pb-20">
          {chapter.blocks.map((block, index) => (
            <ContentRenderer key={`block-${index}`} block={block} index={index} />
          ))}

          {/* End of chapter */}
          <div className="mt-16 rounded-xl border border-border bg-card p-6 text-center sm:p-8">
            <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              <BookOpen className="h-5 w-5 text-primary" />
            </div>
            <h3 className="text-lg font-bold text-foreground">
              {"Fim do Capitulo " + chapter.number}
            </h3>
            <p className="mt-2 text-sm text-muted-foreground">
              {isCompleted
                ? "Voce ja concluiu este capitulo. Continue para o proximo!"
                : "Marque como concluido quando terminar de absorver o conteudo."}
            </p>

            {!isCompleted && (
              <button
                onClick={() => setIsCompleted(true)}
                className="mt-4 inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110"
                type="button"
              >
                <CheckCircle2 className="h-4 w-4" />
                {"Marcar como concluido"}
              </button>
            )}
          </div>

          {/* Navigation */}
          <div className="mt-8 flex items-center justify-between">
            {chapterId > 1 ? (
              <Link
                href={`/dashboard/modulos/${chapterId - 1}`}
                className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-4 py-2.5 text-sm font-medium text-foreground transition-all hover:border-primary/40"
              >
                <ArrowLeft className="h-4 w-4" />
                <span className="hidden sm:inline">{"Capitulo anterior"}</span>
                <span className="inline sm:hidden">{"Anterior"}</span>
              </Link>
            ) : (
              <div />
            )}
            {chapterId < chapters.length ? (
              <Link
                href={`/dashboard/modulos/${chapterId + 1}`}
                className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110"
              >
                <span className="hidden sm:inline">{"Proximo capitulo"}</span>
                <span className="inline sm:hidden">{"Proximo"}</span>
                <ArrowLeft className="h-4 w-4 rotate-180" />
              </Link>
            ) : (
              <Link
                href="/dashboard/modulos"
                className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110"
              >
                {"Ver todos os modulos"}
              </Link>
            )}
          </div>
        </article>
      </div>

      {/* Back to top button */}
      {showBackToTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-6 right-6 z-40 flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg transition-all hover:brightness-110"
          aria-label="Voltar ao topo"
          type="button"
        >
          <ChevronUp className="h-5 w-5" />
        </button>
      )}
    </div>
  )
}
