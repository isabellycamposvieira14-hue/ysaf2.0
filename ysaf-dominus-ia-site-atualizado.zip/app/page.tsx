"use client"

import React, { useState } from "react"
import { useRouter } from "next/navigation"
import { Eye, EyeOff, Lock, Mail, User, Phone, ArrowRight } from "lucide-react"
import { createClient } from "@/lib/supabase/client"

type AuthTab = "login" | "signup"

export default function AuthPage() {
  const [activeTab, setActiveTab] = useState<AuthTab>("login")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const router = useRouter()

  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-1/4 h-[500px] w-[500px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary/10 blur-[120px]" />
        <div className="absolute bottom-0 right-0 h-[300px] w-[300px] rounded-full bg-primary/5 blur-[100px]" />
      </div>

      <div className="relative z-10 mx-auto w-full max-w-md px-6">
        <div className="mb-8 flex flex-col items-center">
          <PantherLogo />
          <h1 className="mt-6 text-balance text-center text-2xl font-bold tracking-tight text-foreground">
            {"Área Exclusiva YSAF Dominus IA"}
          </h1>
          <p className="mt-2 text-center text-sm text-muted-foreground">
            {"Treinamento + eBook para vender e crescer usando IA, automação e marketing."}
          </p>
        </div>

        {/* Tabs */}
        <div className="mb-6 flex rounded-lg border border-border bg-card p-1">
          <button
            type="button"
            onClick={() => { setActiveTab("login"); setError(""); setSuccess("") }}
            className={`flex-1 rounded-md py-2.5 text-sm font-medium transition-all ${
              activeTab === "login"
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Entrar
          </button>
          <button
            type="button"
            onClick={() => { setActiveTab("signup"); setError(""); setSuccess("") }}
            className={`flex-1 rounded-md py-2.5 text-sm font-medium transition-all ${
              activeTab === "signup"
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Criar Conta
          </button>
        </div>

        {error && (
          <div className="mb-4 rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-400">
            {error}
          </div>
        )}

        {success && (
          <div className="mb-4 rounded-lg border border-green-500/30 bg-green-500/10 px-4 py-3 text-sm text-green-400">
            {success}
          </div>
        )}

        {activeTab === "login" ? (
          <LoginForm
            isLoading={isLoading}
            setIsLoading={setIsLoading}
            setError={setError}
            setSuccess={setSuccess}
            router={router}
          />
        ) : (
          <SignupForm
            isLoading={isLoading}
            setIsLoading={setIsLoading}
            setError={setError}
            setSuccess={setSuccess}
            setActiveTab={setActiveTab}
          />
        )}

        <p className="mt-10 text-center text-xs text-muted-foreground">
          {"YSAF Dominus IA \u2014 Todos os direitos reservados."}
        </p>
      </div>
    </main>
  )
}

function LoginForm({
  isLoading,
  setIsLoading,
  setError,
  setSuccess,
  router,
}: {
  isLoading: boolean
  setIsLoading: (v: boolean) => void
  setError: (v: string) => void
  setSuccess: (v: string) => void
  router: ReturnType<typeof useRouter>
}) {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")
    setSuccess("")

    try {
      const supabase = createClient()
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) {
        if (error.message.includes("Invalid login credentials")) {
          setError("E-mail ou senha incorretos. Tente novamente.")
        } else if (error.message.includes("Email not confirmed")) {
          setError("Confirme seu e-mail antes de fazer login. Verifique sua caixa de entrada.")
        } else {
          setError(error.message)
        }
        return
      }

      router.push("/dashboard")
      router.refresh()
    } catch {
      setError("Erro ao conectar. Tente novamente mais tarde.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleLogin} className="space-y-4">
      <div className="group relative">
        <Mail className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground transition-colors group-focus-within:text-primary" />
        <input
          type="email"
          placeholder="Seu e-mail"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="h-12 w-full rounded-lg border border-border bg-card pl-11 pr-4 text-sm text-foreground placeholder:text-muted-foreground transition-all focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
        />
      </div>

      <div className="group relative">
        <Lock className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground transition-colors group-focus-within:text-primary" />
        <input
          type={showPassword ? "text" : "password"}
          placeholder="Sua senha"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          className="h-12 w-full rounded-lg border border-border bg-card pl-11 pr-12 text-sm text-foreground placeholder:text-muted-foreground transition-all focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
        />
        <button
          type="button"
          onClick={() => setShowPassword(!showPassword)}
          className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground transition-colors hover:text-foreground"
          aria-label={showPassword ? "Esconder senha" : "Mostrar senha"}
        >
          {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
        </button>
      </div>

      <button
        type="submit"
        disabled={isLoading}
        className="relative flex h-12 w-full items-center justify-center rounded-lg bg-primary font-semibold text-primary-foreground transition-all hover:brightness-110 disabled:opacity-70"
      >
        {isLoading ? (
          <span className="flex items-center gap-2">
            <span className="h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
            Entrando...
          </span>
        ) : (
          <span className="flex items-center gap-2">
            Entrar na Plataforma
            <ArrowRight className="h-4 w-4" />
          </span>
        )}
      </button>

      <div className="text-center">
        <button
          type="button"
          onClick={async () => {
            if (!email) {
              setError("Digite seu e-mail para recuperar a senha.")
              return
            }
            setIsLoading(true)
            setError("")
            try {
              const supabase = createClient()
              const { error } = await supabase.auth.resetPasswordForEmail(email, {
                redirectTo: `${window.location.origin}/auth/callback?next=/dashboard/perfil`,
              })
              if (error) {
                setError(error.message)
              } else {
                setSuccess("Link de recuperacao enviado para seu e-mail.")
              }
            } catch {
              setError("Erro ao enviar e-mail de recuperacao.")
            } finally {
              setIsLoading(false)
            }
          }}
          className="text-xs text-muted-foreground transition-colors hover:text-primary"
        >
          Esqueceu sua senha?
        </button>
      </div>
    </form>
  )
}

function SignupForm({
  isLoading,
  setIsLoading,
  setError,
  setSuccess,
  setActiveTab,
}: {
  isLoading: boolean
  setIsLoading: (v: boolean) => void
  setError: (v: string) => void
  setSuccess: (v: string) => void
  setActiveTab: (v: AuthTab) => void
}) {
  const [fullName, setFullName] = useState("")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")
    setSuccess("")

    if (password.length < 6) {
      setError("A senha deve ter pelo menos 6 caracteres.")
      setIsLoading(false)
      return
    }

    if (password !== confirmPassword) {
      setError("As senhas nao coincidem.")
      setIsLoading(false)
      return
    }

    try {
      const supabase = createClient()
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo:
            process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL ||
            `${window.location.origin}/auth/callback?next=/dashboard`,
          data: {
            full_name: fullName,
          },
        },
      })

      if (error) {
        if (error.message.includes("already registered")) {
          setError("Este e-mail ja esta cadastrado. Tente fazer login.")
        } else {
          setError(error.message)
        }
        return
      }

      // Send notification to ysafmidia@gmail.com
      try {
        await fetch("/api/notify-signup", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ fullName, email, phone }),
        })
      } catch {
        // Don't block signup if notification fails
      }

      setSuccess(
        "Conta criada com sucesso! Verifique seu e-mail para confirmar o cadastro."
      )
      setFullName("")
      setEmail("")
      setPhone("")
      setPassword("")
      setConfirmPassword("")

      setTimeout(() => setActiveTab("login"), 4000)
    } catch {
      setError("Erro ao criar conta. Tente novamente mais tarde.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSignup} className="space-y-4">
      <div className="group relative">
        <User className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground transition-colors group-focus-within:text-primary" />
        <input
          type="text"
          placeholder="Nome completo"
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          required
          className="h-12 w-full rounded-lg border border-border bg-card pl-11 pr-4 text-sm text-foreground placeholder:text-muted-foreground transition-all focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
        />
      </div>

      <div className="group relative">
        <Mail className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground transition-colors group-focus-within:text-primary" />
        <input
          type="email"
          placeholder="Seu e-mail"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="h-12 w-full rounded-lg border border-border bg-card pl-11 pr-4 text-sm text-foreground placeholder:text-muted-foreground transition-all focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
        />
      </div>

      <div className="group relative">
        <Phone className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground transition-colors group-focus-within:text-primary" />
        <input
          type="tel"
          placeholder="WhatsApp (opcional)"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          className="h-12 w-full rounded-lg border border-border bg-card pl-11 pr-4 text-sm text-foreground placeholder:text-muted-foreground transition-all focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
        />
      </div>

      <div className="group relative">
        <Lock className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground transition-colors group-focus-within:text-primary" />
        <input
          type={showPassword ? "text" : "password"}
          placeholder="Criar senha (min. 6 caracteres)"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          minLength={6}
          className="h-12 w-full rounded-lg border border-border bg-card pl-11 pr-12 text-sm text-foreground placeholder:text-muted-foreground transition-all focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
        />
        <button
          type="button"
          onClick={() => setShowPassword(!showPassword)}
          className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground transition-colors hover:text-foreground"
          aria-label={showPassword ? "Esconder senha" : "Mostrar senha"}
        >
          {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
        </button>
      </div>

      <div className="group relative">
        <Lock className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground transition-colors group-focus-within:text-primary" />
        <input
          type={showPassword ? "text" : "password"}
          placeholder="Confirmar senha"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          required
          minLength={6}
          className="h-12 w-full rounded-lg border border-border bg-card pl-11 pr-4 text-sm text-foreground placeholder:text-muted-foreground transition-all focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
        />
      </div>

      <button
        type="submit"
        disabled={isLoading}
        className="relative flex h-12 w-full items-center justify-center rounded-lg bg-primary font-semibold text-primary-foreground transition-all hover:brightness-110 disabled:opacity-70"
      >
        {isLoading ? (
          <span className="flex items-center gap-2">
            <span className="h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
            Criando conta...
          </span>
        ) : (
          <span className="flex items-center gap-2">
            Criar Minha Conta
            <ArrowRight className="h-4 w-4" />
          </span>
        )}
      </button>

      <p className="text-center text-xs text-muted-foreground">
        {"Ao criar sua conta, voce concorda com nossos termos de uso e politica de privacidade."}
      </p>
    </form>
  )
}

function PantherLogo() {
  return (
    <svg
      width="64"
      height="64"
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="drop-shadow-[0_0_15px_hsla(260,100%,59%,0.5)]"
      aria-label="YSAF Dominus IA Logo"
    >
      <circle cx="32" cy="32" r="30" stroke="hsl(260 100% 59%)" strokeWidth="2" fill="hsl(255 30% 10%)" />
      <path
        d="M20 22C20 22 24 18 32 18C40 18 44 22 44 22C44 22 46 26 46 30C46 34 44 38 42 40C40 42 38 44 36 45C34 46 32 47 32 47C32 47 30 46 28 45C26 44 24 42 22 40C20 38 18 34 18 30C18 26 20 22 20 22Z"
        fill="hsl(260 100% 59%)"
        opacity="0.15"
      />
      <path
        d="M26 28C26 28 28 26 32 26C36 26 38 28 38 28L40 32C40 34 38 38 36 40L32 43L28 40C26 38 24 34 24 32L26 28Z"
        fill="hsl(260 100% 59%)"
        opacity="0.3"
      />
      <circle cx="27" cy="30" r="2" fill="hsl(260 100% 75%)" />
      <circle cx="37" cy="30" r="2" fill="hsl(260 100% 75%)" />
      <path
        d="M29 35C29 35 30.5 37 32 37C33.5 37 35 35 35 35"
        stroke="hsl(260 100% 75%)"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      <path
        d="M18 24L14 18M46 24L50 18M18 36L12 40M46 36L52 40"
        stroke="hsl(260 100% 59%)"
        strokeWidth="1.5"
        strokeLinecap="round"
        opacity="0.5"
      />
    </svg>
  )
}
