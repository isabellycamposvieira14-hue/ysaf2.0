import React from "react"
import type { Metadata, Viewport } from 'next'
import { Poppins } from 'next/font/google'

import './globals.css'

const poppins = Poppins({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700'],
  variable: '--font-poppins',
})

export const metadata: Metadata = {
  title: 'YSAF Dominus IA - Área de Membros',
  description: 'Treinamento + eBook para vender e crescer usando IA, automação e marketing. Area exclusiva para membros YSAF Dominus IA.',
}

export const viewport: Viewport = {
  themeColor: '#0B0B0F',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR" className={poppins.variable}>
      <body className="font-sans antialiased">{children}</body>
    </html>
  )
}
